package AVL;
import queueGenerica.Queue;
import stackGenerica.Stack;

public class AVL<T extends Comparable<T>> {
    private AVLNode<T> root;
    private boolean status;
    
    public boolean isEmpty(){
        return this.root==null;
    }

    public void insert(T valor){
        if(this.isEmpty()){
            this.root = new AVLNode<>(valor);
        }else{
            this.root = insertNode(this.root, valor);
            this.status = false;
        }
    }
    private AVLNode<T> insertNode(AVLNode<T>node, T valor){
        if(node == null){
            node = new AVLNode<>(valor);
            this.status = true;
        } else if(node.getInfo().compareTo(valor) > 0){
            node.setLeft(insertNode(node.getLeft(), valor));
            if(this.status){
                switch (node.getFatBal()) {
                    case 1 -> { 
                        node.setFatBal(0);
                        this.status = false;
                    }
                    case 0 -> node.setFatBal(-1);
                    case -1 -> node = this.rotateRight(node);
                }
            }
        } else {
            node.setRight(insertNode(node.getRight(), valor));
            if(this.status){
                switch (node.getFatBal()) {
                    case -1 -> { 
                        node.setFatBal(0);
                        this.status = false;
                    }
                    case 0 -> node.setFatBal(1);
                    case 1 -> node = this.rotateLeft(node);
                }
            }
        }
        return node;
    }

    private AVLNode<T> rotateLeft(AVLNode<T> a){
        AVLNode<T> b,c;
        b = a.getLeft();
        if(b.getFatBal()==1){ //rotacao simples
            a.setRight(b.getLeft());
            b.setLeft(a);
            a.setFatBal(0);
            a=b;
        }
        else{ //rotacao dupla
            c = b.getLeft();
            b.setLeft(c.getRight());
            c.setRight(b);
            a.setRight(c.getLeft());
            c.setLeft(a);
            if(c.getFatBal()==1){
                a.setFatBal(-1);
            }
            else{
                a.setFatBal(0);
            }
            a=c;
        }
        a.setFatBal(0);
        this.status=false;
        return a;
    }

    private AVLNode<T> rotateRight(AVLNode<T> a){
        AVLNode<T> b,c;
        b = a.getLeft();
        if(b.getFatBal()==-1){ //rotacao simples
            a.setLeft(b.getRight());
            b.setRight(a);
            a.setFatBal(0);
            a=b;
        }
        else{ //rotacao dupla
            c = b.getRight();
            b.setRight(c.getLeft());
            c.setLeft(b);
            a.setLeft(c.getRight());
            c.setRight(a);
            if(c.getFatBal()==-1){
                a.setFatBal(1);
            }
            else{
                a.setFatBal(0);
            }
            if(c.getFatBal()==1){
                b.setFatBal(0);
            }
            a=c;
        }
        a.setFatBal(0);
        this.status=false;
        return a;
    }

    public void emOrdem(){
        if(this.isEmpty()){
            System.out.println("arvore vazia!");
        }
        else{
            System.out.println("Em ordem-> ");
            Stack<AVLNode<T>> pilha = new Stack<AVLNode<T>>();
            AVLNode<T> aux = this.root;
            while(!pilha.isEmpty() || aux!=null){
                while(aux!=null){
                    pilha.push(aux);
                    aux = aux.getLeft();
                }
                aux = pilha.pop();
                System.out.println(aux.getInfo()+" ");
                aux = aux.getRight();
            }
            System.out.println();
        }        
    }

    public void porNivel(){
        if(this.isEmpty()){
            System.out.println("arvore vazia!\n");
        }
        else{
            System.out.println("por nivel-> ");
            Queue<AVLNode<T>> fila = new Queue<AVLNode<T>>();
            AVLNode<T> aux;
            fila.enQueue(this.root);
            while(!fila.isEmpty()){
                aux = fila.deQueue(); //primeiro nivel (root) ja é retirado da fila
                if(aux!=null && aux.getLeft()!=null && aux.getRight()!=null){
                    fila.enQueue(aux.getLeft());
                    fila.enQueue(aux.getRight());
                }
                else if(aux==null){
                    System.out.println("null ");
                }
                else{
                    System.out.println(aux.getInfo()+" ");
                }
            }
            System.out.println();
        }
    }

    private int getBalanceFactor(AVLNode<T> node) { //calcula a diferença de altura entre subarvores
        if (node == null) {
            return 0;
        }
        return height(node.getLeft()) - height(node.getRight());
    }
    
    private int height(AVLNode<T> node) { //calcula altura de arvores;subarvores a partir de node
        if (node == null) {
            return 0;
        }
        return 1 + Math.max(height(node.getLeft()), height(node.getRight()));
    }

    public void remove(T valor){
        if(this.isEmpty()){
            System.out.println("arvore vazia");
        }
        else{
            this.root = removeNode(this.root, valor);
            this.status = false;
        }
    }

    private AVLNode<T> removeNode(AVLNode<T> r, T valor){
        if(r!=null){
            int resultado = valor.compareTo(r.getInfo());
            if(resultado==0){
                if(r.getLeft()==null && r.getRight()==null){
                    r=null;
                }
                else if(r.getLeft()==null){
                    r=r.getRight();
                }
                else if(r.getRight()==null){
                    r=r.getLeft();
                }
                else{
                    AVLNode<T> pai, filho;
                    pai=r;
                    filho=pai.getLeft();
                    if(filho.getRight()!=null){
                        while(filho.getRight()!=null){
                            pai=filho;
                            filho=filho.getLeft();
                        }
                        pai.setRight(filho.getLeft());
                    }
                    else{
                        pai.setLeft(filho.getLeft());
                    }
                    r.setInfo(filho.getInfo());
                }
            }
            else if(resultado<0){
                r.setLeft(removeNode(r.getLeft(), valor));
            }
            else{
                r.setRight(removeNode(r.getRight(), valor));
            }
        }
        
        if(r==null){
            return r;
        }

        r.setFatBal(getBalanceFactor(r));

        if (r.getFatBal() > 1) {
            if (getBalanceFactor(r.getLeft()) >= 0) {
                return rotateRight(r);
            }
            else {
                r.setLeft(rotateLeft(r.getLeft()));
                return rotateRight(r);
            }
    }

        if (r.getFatBal() < -1) {
            if (getBalanceFactor(r.getRight()) <= 0) {
                return rotateLeft(r);
            }
            else {
                r.setRight(rotateRight(r.getRight()));
                return rotateLeft(r);
            }
        }
    return r;
    }
}